
// liste des séquence de commandes à envoyer à l'Arduino
let lcmd = []

// numéro de la séquence courante
let num = 0 

// port xbee
let xbee = null

let nom_mission = null


// sauvegarde valeurs variables
let dist = null
let v = null
let dt = null

function init(xb,nom,vitesse,duree,distance) {
    console.log("init mission "+nom+" vitesse = "+vitesse+" durée = " + duree+" distance arrêt = "+distance)

    xbee = xb

    nom_mission = nom

    dist = distance
    v = vitesse
    dt = duree

    num = 0
}

function exec(etat) {
    let ddist = dist-etat.d1

    if (ddist>1) {
        lcmd = [`[[mda ${v-ddist}][mga ${v}][t ${dt}]]`]
    }
    else if (ddist<-1) {
        lcmd = [`[[mda ${v}][mga ${v+ddist}][t ${dt}]]`]
    }
    else {
        lcmd = [`[[mda ${v}][mga ${v}][t ${dt}]]`]
    }

    console.log("exec mission "+nom_mission+" etat = "+JSON.stringify(etat))

    if (xbee != null) {
        console.log("envoi séquence "+lcmd[num])
        xbee.write(lcmd[num])
    }
}

module.exports = {
    init : init,
    exec : exec,
}

